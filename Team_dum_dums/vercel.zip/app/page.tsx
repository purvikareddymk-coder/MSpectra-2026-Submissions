"use client"

import { useState, useCallback } from "react"
import { FileUpload } from "@/components/file-upload"
import { RequirementsTable, type Requirement } from "@/components/requirements-table"
import { Button } from "@/components/ui/button"
import { Spinner } from "@/components/ui/spinner"
import { Monitor, Code, Download, FileSpreadsheet } from "lucide-react"

// Sample data to simulate processing results
const sampleHardwareRequirements: Requirement[] = [
  {
    id: "hw1",
    name: "Server",
    specification: "Intel Xeon E5-2680 v4, 64GB RAM",
    quantity: "2",
    notes: "Primary and backup servers",
  },
  {
    id: "hw2",
    name: "Workstation",
    specification: "Intel Core i7-12700K, 32GB RAM",
    quantity: "15",
    notes: "Development team workstations",
  },
  {
    id: "hw3",
    name: "Network Switch",
    specification: "48-port Gigabit Managed Switch",
    quantity: "3",
    notes: "Building floors 1-3",
  },
  {
    id: "hw4",
    name: "Storage Array",
    specification: "100TB NAS, RAID 6 Configuration",
    quantity: "1",
    notes: "Data center storage",
  },
]

const sampleSoftwareRequirements: Requirement[] = [
  {
    id: "sw1",
    name: "Operating System",
    specification: "Windows 11 Pro / Ubuntu 22.04 LTS",
    quantity: "17 licenses",
    notes: "Mixed environment",
  },
  {
    id: "sw2",
    name: "Database",
    specification: "PostgreSQL 15 Enterprise",
    quantity: "2 instances",
    notes: "Production and staging",
  },
  {
    id: "sw3",
    name: "IDE License",
    specification: "JetBrains All Products Pack",
    quantity: "15 seats",
    notes: "Annual subscription",
  },
  {
    id: "sw4",
    name: "Cloud Platform",
    specification: "AWS Enterprise Support",
    quantity: "1 account",
    notes: "Including reserved instances",
  },
]

export default function FileProcessorDashboard() {
  const [file, setFile] = useState<File | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [hardwareRequirements, setHardwareRequirements] = useState<Requirement[]>([])
  const [softwareRequirements, setSoftwareRequirements] = useState<Requirement[]>([])
  const [hasProcessed, setHasProcessed] = useState(false)

  const handleFileSelect = useCallback((selectedFile: File | null) => {
    setFile(selectedFile)
    if (!selectedFile) {
      setHardwareRequirements([])
      setSoftwareRequirements([])
      setHasProcessed(false)
    }
  }, [])

  const handleProcessFile = useCallback(async () => {
    if (!file) return

    setIsProcessing(true)
    
    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 2000))
    
    // Set sample data (in a real app, this would parse the file)
    setHardwareRequirements(sampleHardwareRequirements)
    setSoftwareRequirements(sampleSoftwareRequirements)
    setHasProcessed(true)
    setIsProcessing(false)
  }, [file])

  const handleExport = useCallback(() => {
    // Create CSV content
    const headers = ["Category", "Name", "Specification", "Quantity", "Notes"]
    const hardwareRows = hardwareRequirements.map((r) => [
      "Hardware",
      r.name,
      r.specification,
      r.quantity,
      r.notes,
    ])
    const softwareRows = softwareRequirements.map((r) => [
      "Software",
      r.name,
      r.specification,
      r.quantity,
      r.notes,
    ])

    const csvContent = [
      headers.join(","),
      ...hardwareRows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
      ...softwareRows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
    ].join("\n")

    // Download CSV
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "requirements-export.csv"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, [hardwareRequirements, softwareRequirements])

  const hasResults = hardwareRequirements.length > 0 || softwareRequirements.length > 0

  return (
    <main className="min-h-screen bg-background relative">
      {/* Watermark */}
      <div
        className="fixed inset-0 flex items-center justify-center pointer-events-none select-none z-0"
        aria-hidden="true"
      >
        <div className="flex flex-col items-center text-6xl md:text-8xl lg:text-9xl font-bold text-foreground/[0.04] uppercase tracking-widest leading-tight">
          <span>Acceleron</span>
          <span>Labs</span>
        </div>
      </div>
      {/* Header */}
      <header className="border-b-2 border-border bg-secondary relative z-10">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <FileSpreadsheet className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-2xl font-bold text-secondary-foreground uppercase tracking-wide">
                Requirements Analyzer
              </h1>
              <p className="text-sm text-secondary-foreground/70">
                Upload your specification documents to extract requirements
              </p>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8 relative z-10">
        {/* Step 1: Upload File */}
        <section className="mb-8">
          <h2 className="text-lg font-bold text-foreground uppercase tracking-wide mb-4">
            Step 1: Upload File
          </h2>
          <p className="text-muted-foreground mb-4">
            Upload a PDF or Excel file containing your project specifications.
          </p>
          <FileUpload file={file} onFileSelect={handleFileSelect} />
        </section>

        {/* Step 2: Process File */}
        <section className="mb-8">
          <h2 className="text-lg font-bold text-foreground uppercase tracking-wide mb-4">
            Step 2: Process File
          </h2>
          <div className="flex items-center gap-4">
            <Button
              onClick={handleProcessFile}
              disabled={!file || isProcessing}
              className="min-w-[160px]"
            >
              {isProcessing ? (
                <>
                  <Spinner className="mr-2" />
                  Processing...
                </>
              ) : (
                "Process File"
              )}
            </Button>
            {isProcessing && (
              <span className="text-muted-foreground text-sm">
                Analyzing document structure...
              </span>
            )}
            {hasProcessed && !isProcessing && (
              <span className="text-primary text-sm font-medium">
                Processing complete!
              </span>
            )}
          </div>
        </section>

        {/* Results Section */}
        <section className="space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-foreground uppercase tracking-wide">
              Extracted Requirements
            </h2>
            {hasResults && (
              <Button variant="outline" onClick={handleExport}>
                <Download className="h-4 w-4 mr-2" />
                Export to CSV
              </Button>
            )}
          </div>

          {/* Hardware Requirements */}
          <RequirementsTable
            title="Hardware Requirements"
            requirements={hardwareRequirements}
            icon={<Monitor className="h-5 w-5 text-primary" />}
          />

          {/* Software Requirements */}
          <RequirementsTable
            title="Software Requirements"
            requirements={softwareRequirements}
            icon={<Code className="h-5 w-5 text-primary" />}
          />
        </section>
      </div>

      {/* Footer */}
      <footer className="border-t-2 border-border mt-12 py-6 relative z-10">
        <div className="max-w-6xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>Requirements Analyzer — Extract and manage project specifications</p>
          <p className="mt-1">Team - Subhashini and Purvika</p>
        </div>
      </footer>
    </main>
  )
}
