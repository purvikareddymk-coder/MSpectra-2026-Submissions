"use client"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

export interface Requirement {
  id: string
  name: string
  specification: string
  quantity: string
  notes: string
}

interface RequirementsTableProps {
  title: string
  requirements: Requirement[]
  icon: React.ReactNode
}

export function RequirementsTable({ title, requirements, icon }: RequirementsTableProps) {
  return (
    <div className="border-2 border-border">
      <div className="border-b-2 border-border bg-secondary px-4 py-3 flex items-center gap-3">
        {icon}
        <h2 className="text-lg font-bold text-secondary-foreground uppercase tracking-wide">
          {title}
        </h2>
      </div>
      <div className="bg-card">
        <Table>
          <TableHeader>
            <TableRow className="border-b-2 border-border hover:bg-transparent">
              <TableHead className="font-bold uppercase text-xs tracking-wider text-foreground">
                Name
              </TableHead>
              <TableHead className="font-bold uppercase text-xs tracking-wider text-foreground">
                Specification
              </TableHead>
              <TableHead className="font-bold uppercase text-xs tracking-wider text-foreground">
                Quantity
              </TableHead>
              <TableHead className="font-bold uppercase text-xs tracking-wider text-foreground">
                Notes
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {requirements.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                  No requirements found. Process a file to see results.
                </TableCell>
              </TableRow>
            ) : (
              requirements.map((req) => (
                <TableRow key={req.id} className="border-b border-border/50">
                  <TableCell className="font-medium">{req.name}</TableCell>
                  <TableCell>{req.specification}</TableCell>
                  <TableCell>{req.quantity}</TableCell>
                  <TableCell className="text-muted-foreground">{req.notes}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
